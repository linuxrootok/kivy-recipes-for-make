.. _bestpractices:

Best Practices
==============

Designing your Application code
-------------------------------

Handle Window re-sizing
-----------------------

Managing resources
------------------

 - Atlas
 - Cache
    - Images
    - Text

Platform consideration
----------------------

Tips and Tricks
---------------

 - Skinning
 - Using Modules
    - Monitor
    - Inspector
    - Screen
 - Kivy-Remote-Shell
