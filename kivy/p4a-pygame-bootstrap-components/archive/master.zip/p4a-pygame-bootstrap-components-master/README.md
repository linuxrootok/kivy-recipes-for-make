# Pygame bootstrap JNI components for python-for-android

This repository holds the files for the different projects compiled by
the pygame bootstrap of python-for-android (p4a). In the original p4a
project these were included in the repository, but are now downloaded
from here to save space.
